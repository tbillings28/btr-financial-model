import React from 'react';
import BTRFinancialModelPrototype from './BTRFinancialModelPrototype';
import './BTRFinancialModel.css';

function App() {
  return (
    <div className="App">
      <BTRFinancialModelPrototype />
    </div>
  );
}

export default App;
